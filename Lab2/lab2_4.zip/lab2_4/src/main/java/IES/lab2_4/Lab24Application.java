package IES.lab2_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab24Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab24Application.class, args);
	}

}
